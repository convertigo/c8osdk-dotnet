﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Convertigo.SDK
{
    public class C8oPlatform
    {
        static public void Init()
        {
            C8oFullSyncCbl.Init();
        }
    }
}
