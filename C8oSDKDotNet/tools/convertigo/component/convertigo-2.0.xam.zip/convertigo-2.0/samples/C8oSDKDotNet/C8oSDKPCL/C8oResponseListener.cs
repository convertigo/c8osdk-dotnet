﻿using Convertigo.SDK.C8oEnum;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Convertigo.SDK
{
    public interface C8oResponseListener
    {        
    }
}
